#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	char str[10000];
	char str1[10000];
	char str2[10000];
	char str3[10000];
	char s[1000];
	int i,j,k,l,m,n,t=25;
	bool map[50000];
	//FILE *p=fopen("multiPTM.txt","r");
	FILE *p1=fopen("RC.txt","r");
	FILE *p2=fopen("K-space.txt","r");
	FILE *p3=fopen("PSAAP.txt","r");
	
	freopen("feature.txt","w",stdout);
	while(fgets(str,10000,p1))
	{
		//fgets(str1,10000,p1);
		fgets(str2,10000,p2);
		fgets(str3,10000,p3);
		l=strlen(str);
		str[l-1]='\0';
		l=strlen(str1);
		str1[l-1]='\0';
		l=strlen(str2);
		str2[l-1]='\0';
		
		printf("%s %s %s",str,str2,str3);
	}
	
}

