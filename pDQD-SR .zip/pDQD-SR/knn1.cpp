#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;

int main()
{
	char s[2000][1000];
	//
	char str[2000];
	char name[100];
	char name1[100]; 
	int i,j,k,l,m,n,t1,t2,sum;
	//
	FILE *p=fopen("IG_89.txt","r");
	FILE *p1=fopen("knn_result.txt","r");
	
	i=0;
	while(fgets(s[i],1000,p))
	{
		i++;
	}
	//printf("%d",n);
	i=1;
	while(fgets(str,1000,p1))
	{
		sprintf(name,"%d.txt",i);
		sprintf(name1,"label_%d.txt",i++);
		FILE *p0=fopen(name,"w");
		FILE *p00=fopen(name1,"w");
		l=strlen(str);
		str[l-1]='\0';
		char *pp=strtok(str," ");
		while(pp!=NULL)
		{
			k=atoi(pp);
			pp=strtok(NULL," ");
			fprintf(p0,"%s",s[k]);
			if(k<723)
			fprintf(p00,"1\n");
			else
			fprintf(p00,"-1\n");
		}
		fclose(p0);
		fclose(p00);
	}
}

