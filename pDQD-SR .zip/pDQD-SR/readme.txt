KNN.cpp and knn1.cpp selects 4 nearest neighbors for each sample according to peptide;
